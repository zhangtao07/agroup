FEX 内部知识库
========

这个项目用于放置一些内部文档及任务管理

## 文库阅读团队帐号

* 注：写之前先与 rank 商量。
  * 2014 下半年《现代化的前端开发》，现进行目录编写。全团队参与。
  * 2014.7 月 《HTTP 2.0 协议》中文翻译首发。
* user: FEX_team
* pass: fex123465
* [写书链接](http://yuedu.baidu.com/partner/browse/myworks) 

## 内部常用链接

* [FEX 成员名录](fex/team.md)
* [周报系统](http://fe.baidu.com/doc/fex/weekly/)
* [FEX产品列表](tech/product-list.md)
* [文章积分排名榜](http://dp.baidu.com/fex/rank/)
* [HR 人事支持](http://myhr.baidu.com/hrService.jsp)
* [度学堂](http://learn.baidu.com/) ：诸多精品视频和学习资料，快速成长的最好平台之一
* [百度知识库-Babel](http://babel.baidu.com/)
* [百度 FE](http://fe.baidu.com/)

## 技术概况

FEX专注于利用技术去改变前端应用的研发现状，并努力探索面向未来的研发模式。包括如下技术方向：

* 前端工程架构：
* 复杂应用：
* 数据：收集和分析前端相关的全部数据
* 端技术：
* X ：特别行动组，解决无法归属到现有技术方向的难题，从全栈、全端角度探索Web应用研发技术。

技术全景图如下：

![fex tech](tech/fex-tech-2014.04.png)

## FEX 技术产品列表

* 官网：http://fex.baidu.com
* 孵化: http://fuhua.baidu.com
* GMU：http://gmu.baidu.com
* DP: http://dp.baidu.com
* hunter: http://hunter.baidu.com
* UEditor：http://ueditor.baidu.com
* 数说：http://shushuo.baidu.com
* 脑图：http://naotu.baidu.com
* FIS：http://fis.baidu.com
* 云服务：http://solar.baidu.com

## 例行事务

分三类：

- 技术：**多益负责**，保证技术及项目稳步前进；
- 人员：**牛尧负责**，保证人员良性发展；
- 团队：**平川负责**，保证团队良性发展，整体目标稳步推进

| 类别 | 事务项 | 负责人 | 工作内容 |
| :------------ |:---------------:|:---------------|---------------------------------------|
| 技术 | 技术规划 | 多益 | 组织技术规划，保证执行 |
| 技术 | 技术述职 | 多益 | 半年一次，方向负责人介绍进展及规划 |
| 技术 | 技术交流 | 战毅 | 不定期举行，面向 fex 全体成员，30-60分钟 |
| 技术 | 知识沉淀 | 牛尧 | 推动部门知识库建设，发掘有价值的成果并推动沉淀 |
| 人员 | 招聘 | 牛尧 | 确定招聘需求、筛选简历、组织面试 |
| 人员 | 新人培养 |  | 帮助新人快速融入团队、掌握所需技能，组织试用期评估 |
| 人员 | 工程师成长支持 |  | 通过导师、培训、one-one 等辅助工程师成长 |
| 团队 | 品牌建设 | 平川 | 对内对外交流、成果推广等 |
| 团队 | 项目例会 | 平川 | 保证项目的顺利执行 |
| 团队 | 绩效考核 | 平川 | 半年一次，组织：总结、绩效评估、制定新的KPI、绩效面谈 |
| 团队 | team building | 潘征 | 各小组轮流担任 cfo ， 组织部门活动、礼品发放等工作|
| 团队 | **职称评定** | 多益 | 每年2月、8月启动，指导填写申请，组织评定 |

**注：**知识沉淀是新人培养、工程师成长的重要支撑，请大家在“新人相关”和“学习 & 成长”章节补充内容。

## 技术规划

* [必看]刘彭程-如何做技术规划： [视频](http://learn.baidu.com/courseInfo.html?courseId=2786)、[PPT](tech/doc/how_to_make_tech_plan.pdf)、[规划样板-贴吧理想架构](tech/doc/tech_plan_sample.pdf)、[规划样板-贴吧技术规划2013上](tech/doc/tieba_tech_plan_2013.pptx)

## 招聘

* [职位描述](hr/job_description.md)
* [招聘工作简介](hr/README.md)
* [简历筛选原则](hr/resume_screening.md)
* [笔试题库](hr/coding-test-questions.md)
* [技术面试指南](hr/technical_interview.md)

## 新人相关

* [给 FEX 新员工的一封信](newbie/first-letter.md)
* [试用期转正评估流程](http://myhr.baidu.com/service/findServiceDetail.do?id=555&tabId=839&pid=2)
* [FEX 试用期评估表](fex/assessment/fex_newbie_assessment_template.xls)
* [FEX 新人指南](newbie/index.md)
* [FEX 新人培训](newbie/training.md)
* [FEX 编码规范](https://github.com/fex-team/styleguide)
* [Mac 环境配置打印机](newbie/mac-setting-printer.md)
* [翻墙指南](newbie/wfg.md)
* [百度文化论语](http://family.baidu.com/portal/newsDetail?articleId=668941958)
* [员工通用能力提升课程](http://learn.baidu.com/specialListable.html?specialId=2102)

## 学习 & 成长

### BIT培训

* [CBG FE培训计划](fex/courses.md)

### 推荐阅读

* [寒门再难出贵子](http://www.mtyyw.com/7013/)，虽然和我们这不一样，但看看别人的发展过程还是挺有启示的
* [好技术领导，差技术领导](http://blog.jobbole.com/58681/)
* [团队功能失调的七个原因](http://www.managershare.com/2012/10/13/7-reasons-good-teams-become-dysfunctional/)
* [某百度员工离职总结：如何做个好员工？](http://mp.weixin.qq.com/s?__biz=MzA3MDMyODYyOA==&mid=200222421&idx=1&sn=ee08905ff5a69fb6600e30a9694795e6)
* [迄今为止见过最好的职业规划](http://www.360doc.com/content/13/0512/16/3125585_284829243.shtml)  
* [别把你的20多岁浪费给谷歌和麦肯锡 ](http://mp.weixin.qq.com/s?__biz=MzA4ODM1MTMzMQ==&mid=200424900&idx=1&sn=3ce27521351880bfe246fa262c56bcd7)  核心在珍惜青春，走自己的路
### 项目运作

* [项目描述模板](http://fe.baidu.com/doc/fex/weekly/empty-project.md) ，每个项目创立时，要按照这个模板完成项目描述，并提交多益 review。
参考样例：[markdown编辑器](http://fe.baidu.com/doc/fex/weekly/project.php?path=f-cube/dora.md)
* [项目负责人的七大意识](training/7_important_things_about_project_leader.pptx)
* [团队合作](training/work-as-a-team.pptx)

### 技术

* [设计样本-RAL 2.0](http://man.baidu.com/inf/odp/ral2/design/)
* [Front-end Feeds](https://github.com/impressivewebs/frontend-feeds) 想了解前沿技术，请多去看看
* [FEX大学堂](https://github.com/fex-team/fex-edu)
* [FEX技术分享](https://speakerdeck.com/baidufe)
* [FEX技术分享模板](https://github.com/fex-team/internal/blob/master/fex/ppt/FEX.pptx)

### 产品设计

* [产品设计学习资料](training/product_design.md)

### 职业技能

* [通用能力提升推荐书库](http://learn.baidu.com/specialListable.html?specialId=1660)
* 多益-工程师的个人发展规划：[视频](http://learn.baidu.com/courseInfo.html?courseId=2831)、[PPT](https://speakerdeck.com/baidufe/gong-cheng-shi-de-ge-ren-fa-zhan-gui-hua)
* [如何做调研](training/how-to-do-tech-investigate.rar)
* [如何串讲](training/how-to-do-system-study.rar)
* 张猛-识人&带人：[PPT](training/identifying_and_cultivating_high_potential_employees.pptx)
* [berg-如何写技术文章](http://cnberg.com/uploads/Download/tech-articles.pdf)
* [王汎森-怎样写一篇优秀论文](http://www.douban.com/group/topic/31201729/)


## 绩效考核

* [绩效评估模板-T4-工程师](fex/assessment/fex_t4-_assessment_template.xls)
* [绩效评估模板-T5+工程师](fex/assessment/fex_t5+_assessment_template.xls)
* [半年总结模板](fex/assessment/summery.doc)

## 职称评定

每年2月、8月评定一次，需要申请的同学务必请先阅读：

* **[CBG-技术人员能力模型](fex/assessment/tech_competency_model.pdf)** : 与每位工程师的成长息息相关，请务必阅读
* [百度技术职称评定流程](http://wiki.babel.baidu.com/twiki/bin/view/Com/TcRelease/%E7%99%BE%E5%BA%A6%E6%8A%80%E6%9C%AF%E8%81%8C%E7%A7%B0%E8%AF%84%E5%AE%9A%E6%B5%81%E7%A8%8B-new)
* [CBG-工程师职称标准](http://wiki.baidu.com/pages/viewpage.action?pageId=34276314) 核心准则
* [百度WEB前端研发工程师职称细则](fex/assessment/fe_technical_level_standard.docx) 参考
* [申请材料样例](fex/assessment/fe_technical_application_sample.md)
* [述职参考](fex/assessment/tech-presentation-guide.md)

其中，《百度WEB前端研发工程师职称细则》是对《百度工程师职称标准》的详细解读，是 FE 的评定依据。对职称有疑问，可以找多益咨询。

## Team building

* [CFO工作指南](team-building/cfo-handbook.md)
* [团队成员](fex/team.md)

## 品牌建设

* [2014.03 w3ctech baidufex 专场](http://www.w3ctech.com/event/34)
* [fex 2013年工作汇总](http://fex-team.baidu.com/fex2013.html)
* [feday 第一季&第二季](http://fex-team.baidu.com/feday/)

## 经验沉淀

* 2014-05-08 [月度总结 - 方石](summary/personal/2014-04-hefangshi.md)
* 2014-03-28 [KityMinder 开发上线之后的一些总结](summary/minder-experience.md)

## FEX sublime Text license

**为避被封禁，license 请勿外传**

```text
----- BEGIN LICENSE -----
FEX
Single User License
EA7E-929562
C76860FC 14151B54 31E38412 26430932
E776F864 7D7EE835 E95887D4 5CE2C80D
859DDA28 C6579F27 13780987 FBA0F758
DA0E0804 DCC0BF79 3EF90158 0F1B227C
93EEA3E7 FE60F0E8 1A4BFC94 449B2472
5932AA13 3087E2A5 8CCA3308 2BF468A6
85EC9058 DAF36C82 D7C626E8 B32B2AFD
EA1DEBDF B0820E52 295FA972 34753D96
------ END LICENSE ------
```

## 内部调研

* [Google Plus 中用到的技术](research/google-plus.md)

## 部门 TODO

这里先放置简单的想法，后续更多的应该通过 Issues 来管理

- [ ] Pagecheck 开源
- [ ] [部门内部项目接入持续集成](project/travis-ci.md)<https://travis-ci.org>
- [ ] 代码复杂性分析，类似<https://codeclimate.com>
