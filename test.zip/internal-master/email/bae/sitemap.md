# BAE 站点地图

----

+ [百度开放云平台](http://developer.baidu.com/)
    + [轻应用](http://developer.baidu.com/light)
    + [移动应用](http://developer.baidu.com/mobile)
    + [开发者服务](http://developer.baidu.com/services)
        + [应用引擎 BAE](http://developer.baidu.com/cloud/rt)
        + [云存储](http://developer.baidu.com/cloud/stor)
        + [云数据库](http://developer.baidu.com/cloud/db)
        + [云消息](http://developer.baidu.com/cloud/mq)
        + [云推送](http://developer.baidu.com/cloud/push)
        + [媒体云](http://developer.baidu.com/cloud/media)
        + [LBS云](http://lbsyun.baidu.com/)
    + [轻应用管理](http://developer.baidu.com/console#app/light)
    + [移动应用管理](http://developer.baidu.com/console#app/mobile)
    + [开发者服务管理](http://developer.baidu.com/console#app/project)
    + [问题反馈](http://developer.baidu.com/feedback)

### 站点概况

|站点|链接|参考PV|停留时长|点击热力图|
|---|---|---:|---:|---|
|主站首页|[/](http://developer.baidu.com/)|310254|1.53|[查看](images/hunter-bae/developer.baidu.com.jpg)|
|主站开发者服务|[/services](http://developer.baidu.com/services)|61234|2.65|[查看](images/hunter-bae/developer.baidu.com_services.jpg)|
|主站移动应用|[/mobile](http://developer.baidu.com/mobile)|58412|1.87|[查看](images/hunter-bae/developer.baidu.com_mobile.jpg)|
|主站-用户注册|[/user/reg](http://developer.baidu.com/user/reg)|47139|4.03|[查看](images/hunter-bae/developer.baidu.com_user_reg.jpg)|
|主站-用户中心|[/user/info](http://developer.baidu.com/user/info)|44893|2.37|[查看](images/hunter-bae/developer.baidu.com_user_info.jpg)|
|云服务-BAE|[/cloud/rt](http://developer.baidu.com/cloud/rt)|43915|3.62|[查看](images/hunter-bae/developer.baidu.com_cloud_rt.jpg)|
|主站轻应用|[/light](http://developer.baidu.com/light)|25448|2.70|[查看](images/hunter-bae/developer.baidu.com_light.jpg)|
|云服务-云推送|[/cloud/push](http://developer.baidu.com/cloud/push)|14549|15.15|[查看](images/hunter-bae/developer.baidu.com_cloud_push.jpg)|
|主站-用户注册-注册成功|[/user/reg/success](http://developer.baidu.com/user/reg/success)|11795|11.43|[查看](images/hunter-bae/developer.baidu.com_user_reg_success.jpg)|
|主站-用户注册-邮件确认|[/user/reg/email](http://developer.baidu.com/user/reg/email)|6219|10.58|[查看](images/hunter-bae/developer.baidu.com_user_reg_email.jpg)|
|云服务-云存储|[/cloud/stor](http://developer.baidu.com/cloud/stor)|5520|6.73|[查看](images/hunter-bae/developer.baidu.com_cloud_stor.jpg)|
|端服务-获取SDK|[/frontia/sdk](http://developer.baidu.com/frontia/sdk)|5043|4.73|[查看](images/hunter-bae/developer.baidu.com_frontia_sdk.jpg)|
|云服务-云数据库|[/cloud/db](http://developer.baidu.com/cloud/db)|4592|6.42||
|云服务-媒体云|[/cloud/media](http://developer.baidu.com/cloud/media)|2063|9.20||
|云服务|[/cloud](http://developer.baidu.com/cloud)|2043|2.03||
|端服务|[/frontia](http://developer.baidu.com/frontia)|1632|5.68||
|应用服务-个人云存储(PCS)|[/ms/pcs](http://developer.baidu.com/ms/pcs)|1508|6.57||
|云服务-云消息|[/cloud/mq](http://developer.baidu.com/cloud/mq)|1465|4.57||
|端服务-第三方账号登录|[/frontia/sociallogin](http://developer.baidu.com/frontia/sociallogin)|1364|5.78||
|端服务-个人数据存储|[/frontia/pdata](http://developer.baidu.com/frontia/pdata)|1292|4.52||
|端服务-应用数据存储|[/frontia/appdata](http://developer.baidu.com/frontia/appdata)|1164|6.22||
|主站-行业报告|[/report](http://developer.baidu.com/report)|1083|7.93|[查看](images/hunter-bae/developer.baidu.com_report.jpg)|
|端服务-社会化分享|[/frontia/socialshare](http://developer.baidu.com/frontia/socialshare)|1024|9.07||
|端服务-移动统计|[/frontia/mtj](http://developer.baidu.com/frontia/mtj)|652|5.22||
|应用服务-帐号链接(oauth)|[/ms/oauth](http://developer.baidu.com/ms/oauth)|523|6.63||
|应用服务-翻译|[/ms/translate](http://developer.baidu.com/ms/translate)|324|15.13||
|端服务-推送|[/frontia/push](http://developer.baidu.com/frontia/push)|285|4.73||
|应用服务-手机输入法SDK(iOS)|[/ms/input](http://developer.baidu.com/ms/input)|132|5.00||
