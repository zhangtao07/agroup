## 项目参与人

### 项目负责人

* 王集鹄 SOID <wangjihu@baidu.com>

### 用户调研负责人

* 张涛 SOID <zhangtao07@baidu.com>

### 产品负责人

* 徐珣 云平台 <xuxun01@baidu.com>
* 陈轶飞 云平台 <chenyifei@baidu.com>

### 技术接口人

* 陈飞 移动搜索 <chenfei02@baidu.com>

### 前端技术接口人

* 张军 SOID <zhangjun08@baidu.com>
* 杜鸿彬 SOID
* 张慧 云平台 <zhanghui10@baidu.com>

### 设计负责人

* 李旭利 移动用户体验 <lixuli@baidu.com>
* 韩福红 移动用户体验 <hanfuhong@baidu.com>

### 观察者

* 杜熙 云平台 <duxi@baidu.com>
* 王慧 移动搜索 <wanghui@baidu.com>
* 刘平川 SOID <liupingchuan02@baidu.com>
* 沈洪顺 SOID <shenhongshun@baidu.com>
