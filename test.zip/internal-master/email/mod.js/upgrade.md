Mod 升级文档
==================

mod.js 默认已集成在 fis 中，虽然已经能满足大部分用户的 amd 模块化需求，但是还存在一些问题，
需要进行梳理，做一次升级来满足更多的需求。

## 问题收集

1. require.async 不属于 amd  规范。实际上通过 require  是否传入 callback 就可以判断是否为异步。

    ```javascript
    require(['moduleA'], function(moduleA) {
        // empty
    });
    ```
2. require.loadJs 和 require.loadCss 也不在 amd 规范里面，可以考虑去掉这个功能，或者统一通过 `require()` api 加载。

    已有现成 amd css 加载插件： https://github.com/VIISON/RequireCSS

    ```javascript
    require(['moduleA', 'css!xxx.css'], function(moduleA) {
        // empty
    });
    ```
3. 不支持 define(id, deps, factory). 虽然支持 factory 里面写 require 来指定依赖，但是还是有些第三方库是在  define  的时候提前指定依赖的。

    比如：

    ```javascript
    define(["./cart", "./inventory"], function(cart, inventory) {
            //return an object to define the "my/shirt" module.
            return {
                color: "blue",
                size: "large",
                addToCart: function() {
                    inventory.decrement(this);
                    cart.add(this);
                }
            }
        }
    );
    ```

    PS: 这里 module id 没有指出，是因为在编译期 fis 会自动添加。
4. 不支持自定义 module id `define('xxx', deps?, factory);`，虽然 module id fis能自动生成，但是有些第三方库都会自定义 module id. 比如：
  
    ```javascript
    // Register as a named AMD module, since jQuery can be concatenated with other
    // files that may use define, but not via a proper concatenation script that
    // understands anonymous AMD modules. A named AMD is safest and most robust
    // way to register. Lowercase jquery is used because AMD module names are
    // derived from file names, and jQuery is normally delivered in a lowercase
    // file name. Do this after creating the global so that if an AMD module wants
    // to call noConflict to hide this version of jQuery, it will work.
    if ( typeof define === "function" && define.amd ) {
        define( "jquery", [], function () { return jQuery; } );
    }
    ```

    如果此 module id 不是 fis id, 同时其他模块指定该模块为依赖，则依赖不能添加。
5. js wrapper 对 js 的包装不够智能，有的不需要包装的包装了，有的没有指定 id 没有添加上.

    比如下面的这个栗子就多包了一层。

    ```javascript
    define('amdtest:widget/lib/hello/hello.js', function(require, exports, module){

    /**
     * some comments.
     */
    define(['base'], function(Base) {
        
        Base.each([], function() {
            // empty
        });

        return {
            world: function() {
                console.log('world');
            }
        }
    });

    });
    ```
6. 不支持 [shim](https://github.com/amdjs/amdjs-api/blob/master/CommonConfig.md#shim-) 导致，某些库不能以非 amd 的方式加载。

    因为 fis 主要为了实现提前加载模块依赖，可能需要在编译期有同样的 shim 配置支持。 