---
layout: post
title: Nodejs部署手册- F.I.S
category: more
---

# Nodejs部署手册
----------------------

本手册的部署方式是基于NOAH上线进行部署，Node.js部署分为以下几个步骤

* 服务单元管理
* runtime准备
* 业务代码部署
* 服务接入
* 线上监控配置

## 服务单元管理

### 概念介绍

#### 模块

一个模块对应着我们一个独立的项目，如 `app/search/wenku/node/yd/base`

#### 服务实例

一个服务实例对应着一台线上机上承载的一个独立服务，一个独立服务可能包含了多个模块，举例来说，一个传统的UI层项目，会包含多个后端模块和前端模块，只有这些模块同时部署完成后，服务才能正常工作。

总结一下，一台线上机可以包含多个服务实例，但是一个服务实例仅对应一台线上机。一个服务实例可以包含多个模块，而一个模块也可以属于多个服务实例。

#### 服务单元

每一个服务实例均对应一台线上机，很明显是不利于集群管理的，因此就有了服务单元的概念，一个服务单元会包含多个服务实例。

> 服务单元名称由三段组成，形式是” 名称.所在产品线.所在机房 “，比如lighttpd.noah.ai就表示这样一个服务单元”noah产品线在ai机房的lighttpd“。

#### 服务

一般不同机房会配置不同的服务单元，方便流量切换与配置上线，而服务包含了多个机房的服务单元，可以理解为一个虚拟节点。

### 服务单元配置

在OP分配了服务节点后，可以自行添加服务单元

1. 进入http://noah.baidu.com 后，展开左侧的运维树列表，寻找到OP分配的服务节点，右键点击，选择创建节点

    ![](./img/create_service.jpg)

1. 点击服务单元项，进入服务单元创建界面，输入服务名与机房

    ![](./img/create_node.jpg)

1. 双击创建的节点，进入BNS详情，添加机器实例，至此我们就完成了机器与服务单元的绑定

    ![](./img/add_machine.jpg)

1. 点击服务单元详情，并绑定服务单元与模块 **注意** 模块必须在SCM中完成了一次编译后才能正确绑定。

    设置工作账户

    ![](./img/bind_module.jpg)

    添加模块

    ![](./img/bind_module_2.jpg)

1. 至此，我们就完成了模块、机器实例、服务单元之间的绑定工作，接下来就可以进行runtime部署工作了。

## runtime准备

runtime可以直接使用FIS提供的集成环境，其中包含了适用公司线上环境的Node运行时与PM2进程管理工具。

http://fedev.baidu.com/~hefangshi/node_runtime.v0.10.29.tar.gz

后续将会以SVN模块的形式提供node_runtime的，我们可以将FIS的Node集成环境直接添加入服务单元的模块管理中进行上线。

## 业务代码部署

在完成服务单元配置后，我们就可以通过NOAH单进行上线了，添加一个上线单，输入我们的服务单元名称后，就可以看到服务单元下绑定的实例

![](./img/add_noah.jpg)

接下来的工作与普通的NOAH上线步骤类似，选取上线版本与上线文件后进行审核、应用。

## 服务接入

如果是对已有的项目进行改造升级，那么还要考虑服务接入事宜，服务接入包括指定页面的切换与小流量策略。

### 按页面接入

指定页面的切换一般通过webserver中添加转发策略来实现

![](./img/nodejs-deploy-tmp.png)

以nginx为例，我们可以根据http-Location配置特殊处理指定路径，对于/mobile/ydebook的请求，将会使用`server_wenku_nodejs_and_php`后端进行处理。

```bash
location ~ "^/mobile/ydebook"{
    proxy_pass http://server_wenku_nodejs_and_php;
    break;
}
```

为了保证NodeUI的静态资源可以正确获取，所有NodeUI的静态资源在小流量阶段都应该有一个统一的目录进行管理，比如在文库阅读项目中，我们使用的静态资源路径均加了ydnode标示静态资源由NodeUI提供，相应的我们就还需要添加静态资源路由。

```bash
location ~ "^/ydnode"{
    proxy_pass http://server_wenku_nodejs;
    break;
}
```

### 按流量接入

按流量接入可以与按页面接入结合使用，按流量接入需要考虑接入层的情况

如果接入层与PHPUI层是独立的，通过proxy_pass模式连接，那么我们可以通过upstream的weight设置小流量接入。以下配置就是本机PHPUI访问权重为10，NodeUI访问权重为1。

```
upstream server_wenkuphp {
    server 127.0.0.1:8099 max_fails=2 fail_timeout=1s weight=10;
}

upstream server_wenku_nodejs_and_php {
    server 127.0.0.1:8099 max_fails=2 fail_timeout=1s weight=10;
    server 10.50.62.54:8075 max_fails=2 fail_timeout=1s weight=1; #st01-iknow-n01.st01
    server 10.50.127.35:8075 max_fails=2 fail_timeout=1s weight=1; #st01-iknow-n02.st01
    server 10.50.62.55:8075 max_fails=2 fail_timeout=1s weight=1; #st01-iknow-n03.st01
    server 10.50.63.15:8075 max_fails=2 fail_timeout=1s weight=1; #st01-iknow-n04.st01
}
```

如果接入层本身与PHPUI层使用同一个Webserver，采用php-cgi协议交互的话，我们无法通过proxy_pass进行异构backend的分流，因此就只能通过IP、Cookie等数据进行。

```bash
location ~ "^/mobile/ydebook"{
    #cookie中node=1时100%命中nodejs
    if ($http_cookie ~* "node=1"){
        proxy_pass http://server_wenku_nodejs;
        break;
    }
    #根据IP分流
    #此处需要根据环境选择能够获得用户真实IP的header
    if ($remote_addr ~ "[02468]$") { 
        proxy_pass http://server_wenku_nodejs;
        break;
    } 
    fastcgi_pass 127.0.0.1:8099;
}
```

## 线上监控配置

线上监控使用NOAH监控，常规上，我们会对NodeUI的应用报错、自动重启、内存占用进行监控，接下来以文库阅读为例介绍一下配置方法。

```bash
#签出监控3.0配置文件
svn co http://svn.noah.baidu.com/svn/conf/online/wenku/service/nodejs.wenku.all
```

通过instance文件配置监控项

### 应用报错

```json
{
    "raw": [
        {
            "name": "wenku_nodejs_logmon_task_0",
            "cycle": "60",
            "method": "noah",
            "target": "logmon",
            "params": "${ATTACHMENT_DIR}/wenku_nodejs.log.conf.0"
        }
    ],
    "rule": [
        {
            "name": "wenku_nodejs_wenku_nodejs_log_wf_FATAL",
            "formula": "wenku_nodejs_wenku_nodejs_log_wf_FATAL_cnt > 10",
            "filter": "3/3",
            "alert": "wenku_nodejs_default"
        }
    ],
    "alert": [
        {
            "name": "wenku_nodejs_default",
            "max_alert_times": "2",
            "alert_threshold_percent": "0",
            "sms_threshold_percent": 0,
            "remind_interval_second": 0,
            "mail":"fanzhongkai;hefangshi",
            "sms":"fanzhongkai;hefangshi",
        }
    ]
}
```

简单解释一下以上配置。

通过raw配置,我们定义了一个监控项，`wenku_nodejs_logmon_task_0`，使用logmon进行监控，每60秒统计一次，logmon的参数配置在`wenku_nodejs.log.conf.0`中。


通过instance中指定的wenku_nodejs.log.conf.0文件，进行logmon的参数配置

```json
{
    "log_filepath": "/home/iknow/yog/data/log/yd.log.wf.`%Y%m%d%H`",
    "limit_rate": 5,
    "item": [
        {
            "item_name_prefix": "wenku_nodejs_wenku_nodejs_log_wf_FATAL",
            "cycle": "60",
            "match_type": "FUZZ_REGEX",
            "match_str": "FATAL"
        }
    ]
}
```

通过 `log_filepath` 可以配置线上错误日志的地址，`limit_rate` 用于限制每秒读取的日志大小，单位是MB。item则是监控统计结果，`item_name_prefix` 用于定义统计结果名称，`match_type` 和 `match_str` 配 置监听的错误类型。

通过rule配置，我们可以对统计项进行规则定制，`formula` 中的 `wenku_nodejs_wenku_nodejs_log_wf_FATAL_cnt` 就是对监控项 `wenku_nodejs_wenku_nodejs_log_wf_FATAL` 统计次数的引用，`filter: "3/3"` 代表的含义是在3个周期内，每个周期 `formula` 均命中了此规则，就会触发报警。

### 内存监控

除了对日志的监控外，我们还可以直接在rule中添加对CPU和内存的监控

```json
{
    "rule" : [{
        "name":"mem_gt_60",
        "formula":"MEM_USED_PERCENT>60",
        "filter":"5/10",
        "disable_time":["230000-060000"],
        "alert":"wenku_nodejs_default",
    },
    {
        "name":"cpu_idle_lt_50",
        "formula":"CPU_IDLE < 50",
        "filter":"5/10",
        "disable_time":["230000-060000"], 
        "alert":"wenku_nodejs_default",
    }]
}
```

更详尽的使用方法请参考详细配置方法建议查阅[NOAH监控帮助](http://devops.baidu.com/new/argus/class1.md)