Framework
=========================

* 组织结构
* 编写方式对比
* 坑


## 组织结构

基本由不同职责的中间件组成，每个中间件模式很简单。

```javascript
function MiddleWare(request, response, next) {

    
    if (xxx) {
        // 是我要处理的事情我就自己处理

        ...

        // case1:  如果还要其他人插手, 则调用 next()
        next();

        // case2: 否则，直接结束输出。
        response.end();
    } else {

        // 不管我的事，直接丢给其他人。
        next();
    }

}
```

通过 config.json 方便配置，启用或者不启用，通过权重控制执行顺序。

```json
{
    ....

    "middleware": {

        "shutdown": {
            "enabled": true,
            "priority": 0,
            "module": {
                "name": "kraken-js/middleware/shutdown",
                "arguments": [{
                    "timeout": 30000,
                    "template": null
                }]
            }
        },

        "compress": {
            "enabled": false,
            "priority": 10,
            "module": "compression"
        },

        "favicon": {
            "enabled": true,
            "priority": 30,
            "module": {
                "name": "static-favicon",
                "arguments": [ "path:./public/favicon.ico" ]
            }
        },

        ....
    }
}
```

## 编写方式

像传统的 php, 每次请求过来都是一个全新的线程执行脚本，变量都是干净的，代码每一块都会执行一遍。

node 是在服务器开起的时候都加载进来了，每次请求过来的时候，只有 中间件 和 contoller 里面的方法会执行。

缺点： 内存没释放不干净会不停积攒。

优点： 可以做线程级别的缓存。开销小性能快。

异步 可以用简单的回调，或者 promise 方式去编写。

Stream 编写方式. 单一职责, 只关注输入与输出。

## 坑

1. 请求在 close 的时候正在执行的代码不会终止，想在 close 回收内存，导致程序报错。
2. 异步错误通过 domain 都不能捕获，必须严格控制每一次异步才能捕获。
3. render 渲染时对 next 方法的理解不正确，如果 response 已经写入过东西，再调用 next() 会重新发送  header 导致程序出粗。



