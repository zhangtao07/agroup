
# NODE 前后端一体化方案

+ 总体概述
+ framework
    * bigpipe
    * mvc
    * 静态资源管理
+ 部署
+ 运维

## 总体概述

### 背景

文库产品线遇到如下问题；

0. 接口乱

    前端调用的API由于历史原因或其他原因，很乱很杂。通过NODE中间层就可以使前端的保持前端接口的一致性、可维护性。

0. 垃圾请求
    
    现在WebAPP需要渲染一个页面，由于第一次要先把模板请求回来，再请求数据进行填充，这无疑增加了一个数据请求的接口。如果改用后端渲染的方式，则可以减少这个请求。

0. rtt长
    
    可以通过chunk的方式较少RTT时间，可以先渲染首屏。

0. 前端不可控

    如果FE有新的需求，由于需要跟后端讨论接口，定规范；前端就不好控制了。

0. 业务支持度不理想

通过node前后端一体化方案来解决这些问题。

### 总体架构

#### 架构
前后端一体化的架构如下所示；

![](./struct.png)

主要包括三层：

- 浏览器展现层 主要负责页面的渲染（bigpipe）、静态资源管理（cache，require）、展现
- node server层 主要负责后端逻辑、模板拼装、数据请求等
- PHP服务层 主要负责跟数据库交互、数据的挖掘、调用其他系统服务

其中：

+ FIS静态资源管理  指的是对静态资源进行运行时按需加载管理，包括模板的渲染方式等。
+ 运维平台  前期手动运维

#### node server层
node server层，主要体现为一个MVC开发框架（framework）。

![](./node-server.png)

其中包括三个部分；

- http/server node http服务器
- 中间件 主要提供网站开发中需要的各种功能，比如session, form, router, logger等
- config 提供网站的全局配置
- router 路由

#### 浏览器展现层

![](./ui.jpg)

## [Framework](https://github.com/fex-team/yogurt/tree/design) -- 学芝

## [部署](./nodejs-deploy.md) -- 方石

## [运维](./node-operation.md) -- 王程
