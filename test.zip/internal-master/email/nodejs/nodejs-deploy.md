## Node.js部署

* [环境部署](#环境部署)
* [代码发布](#代码发布)
* [流量接入](#流量接入)
* [后续工作](#后续工作)

### 环境部署

Node.js集群部署Nginx和Node.js，Nginx用于分发请求至Node.js后端，并作为接入层接管后续转发需求。Node.js采用进程守护+Cluster模式运行。

#### Node.js环境

受限于公司的编译环境，Node.js无法直接编译通过，与目前已经应用了Node.js的产品线沟通，基本方式还是采用线下升级编译环境，编译完成后上传至线上环境运行。

编译环境升级的方式有多种，目前实践总结了一套最简便的方案。

**建议Nodejs的编译路径与线上路径保持一致**

安装compiler组提供的gcc4.8.3版本的toolchain工具包

```bash
wget http://bpkg.baidu.com/gcc-4.8.3/gcc-4.8.3.01-installer.bin
sh gcc-4.8.3.01-installer.bin path/to/gcc
export PATH=path/to/gcc/bin:$PATH
```

安装Python2.7.6

```bash
bash -c "$( curl http://jumbo.baidu.com/install_jumbo.sh )"; source ~/.bashrc
jumbo install python
```

编译Node.js

```bash
wget http://nodejs.org/dist/v0.10.28/node-v0.10.28.tar.gz
tar -zxvf node-v0.10.28.tar.gz
./configure --prefix path/to/node
make
make test # [01:37|% 100|+ 616|-   3]: Done
make install
```

单测失败的3次测试用例一个是SSL相关，另外两个失败与测试机端口限制有关，待进一步调研。

#### Nginx环境

如果后续Node.js全量上线使用PHP集群的机器，可以考虑使用odp环境的nginx，有利于保障后续与PHP集群整合后的稳定性。

### 代码发布

项目代码中包含前端代码与ui层代码，通过package.json管理依赖。在编译机中按照以下步骤进行编译：

1. 通过fis release编译前端代码
1. 通过npm install安装ui层依赖库
1. 打包发布产品库

线上集群发布时仅需进行代码部署与热加载。

**注意**

第三方C++ addon的支持需调研

### 流量接入

#### 过渡阶段

Node.js集群上仅部署Node.js环境与代码。

PHP集群上的Nginx添加反向代理，将试验迁移的页面的流量分发至Node.js集群。

![部署示例](./nodejs-deploy-tmp.png)

参考配置

```bash
upstream node_backend{
  server ip:port
}

if ($document_uri ~* "(artist)$|(/$)|(/\?)") {
  set $is_uri_webapp  1;
}

if ($is_ua_webapp = $is_uri_webapp) {
  set $nodejs 1;
}

if ($rule_flow_identify = $nodejs) { 
  rewrite  ^(.*)$  /nodejs/$1 break;
}

location ~ ^/nodejs/ {
      rewrite  ^/nodejs/(.*)$  $1  break;
      proxy_pass http://node_backend;
}
```

#### 整站小流量

同步PHP集群与Node.js集群的运行环境，通过Nginx配置提供整站小流量测试能力。

![部署示例](./nodejs-deploy-full.png)

#### Node.js整站切换

修改Nginx配置ui层全部切为Node.js

#### Node.js降级预案

对PHP集群的Nginx配置进行回滚或重新上线，指向本机PHP后端。

### 后续工作

后续将会针对Node.js接入半自动化运维手段，提供基础环境部署、接入层管理、运行监控、上线管理等能力。

![全流程](./nodejs-workflow.png)
