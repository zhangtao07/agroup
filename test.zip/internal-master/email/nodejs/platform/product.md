## 公司内部平台情况

### 上线平台

- NOAH 上线单管理
- ICafe 项目流程与上线单打通
- Archer 上线操作
- Atom ICafe+Archer
- SpeedForce ICafe+Archer
- ORP 环境初始化+资源隔离+ICafe+Archer

### 资源隔离虚拟化

- Matrix
- Jpaas