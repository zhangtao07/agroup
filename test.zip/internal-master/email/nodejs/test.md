### node测试

测试工具统一使用 `mocha`、`chai`、`should`、`supertest`(_如果其他无法实现的需求，使用其他工具后请修改文档_)。

#### package.json

`package.json` 需要添加如下`scripts`和`devDependencies`。

```json
{
  ...
  "scripts": {
    "test": "mocha --reporter dot --check-leaks test/",
    "test-cov": "istanbul cover node_modules/mocha/bin/_mocha -- --reporter dot --check-leaks test/",
    "test-travis": "istanbul cover node_modules/mocha/bin/_mocha --report lcovonly -- --reporter spec --check-leaks test/"
  }
  ...
  "devDependencies": {
    "mocha": "~1.20.1",
    "istanbul": "~0.2.14"
    ...
  }
}

```

