## 概述

### 背景介绍

目前Node解决方案已经在文库落地上线，Node解决方案在应对UI层需求时，往往需要与后端API进行通讯，与传统的前后端接口不同的是，从性能角度出发，我们需要直接与后端PHPUI或CUI进行通讯，而不是直接使用外部域名访问API。

因此在Node解决方案中，我们需要对后端资源访问进行统一的管理，屏蔽实例配置、失败重试、负载均衡等工作，使FE能够专注于UI层业务。

### 相关项目

- RAL
    公司内PHPUI大多使用的后端统一交互层，使用配置文件设置后端资源，在PHP中则可以和调用本地函数一样访问远程资源。本项目的设计中将会大量借鉴RAL的设计。

### 新方法

我们考虑过通过实现RAL的Node版SAPI层来复用RAL的逻辑，但是存在以下几个问题

* RAL设计过程中更多的考虑的是在PHP和HHVM中使用，因而对外接口使用的是同步接口，虽然理论上是线程安全的，但是没有实际多线程调用的场景，因而是一个风险点。
* RAL并未集成mcpack，而是调用的PHP版mcpack，这对于Node来说没有正向收益，我们依然要解决mcpack的包装和编码问题。
* RAL的配置风格偏后端，前端同学并不能很好适应。
* Node已经拥有高效的异步请求能力，如果使用RAL来封装，实际上会重复的进行异步到同步、同步到异步的多次转换，增加系统的复杂性。

基于上述原因，我们考虑自行实现一个Node版的RPC客户端，这个RPC客户端应当拥有以下能力

* 基于可用性与负载反馈的负载均衡能力
* 服务配置能力，内置BNS资源定位与跨机房处理逻辑
* 完善的超时重试机制
* 高效的性能，减少服务端交互以外的性能损耗

我们会根据UI层的需求在RAL的基础上简化功能与实现。

## 整体设计

### 系统架构

系统整体主要分为五个模块

- Config
    负责解析配置，包含BNS的服务解析能力，初期不考虑热加载能力

- Balance
    负责在多个服务间根据负载均衡策略选择一台可用服务实例

- Converter
    负责客户端输入数据的编码以及服务端返回数据的解码工作，默认支持json, form, raw, mcpack

- Protocol
    负责定义RPC请求协议，默认支持http, nshead，后续考虑支持fastcgi

- RPC
    负责框架整体流程控制，调用其余模块完成RPC请求

### 外部接口

#### Config

```javascript
function getIDC() {}
function setIDC() {}
function getServer(serviceName, balanceKey){}
function getServiceInfo(serviceName){}
function getServerList(serviceName) {}
```

#### Protocol

```javascript
function setRetry(retry) {}
function setTimeout(millsec) {}

//各个协议还可以自行扩展接口，如HTTP协议
function setUrl(url) {}
function setHeaders(headers) {}
function setUserAgent(userAgent) {}
function setReferer(referer) {}
```

#### Rpc

```javascript
function getServiceInfo(){}
function getServerList() {}
function setMethod(method) {}
function setData(data) {}
function constructor(serviceName, options) {}

//声明RPC服务
var bookInfo = rpc('bookService', {
    method: "GET",
    headers: {}
    data: {
        tid: 10000
    },
    url: '/getBookInfo'
});

//属性与方法调用互通
bookInfo.setMethod('POST')
        .setData({
            tid: 10001
        });

//穿透调用Protocol接口 注：Protocol中的函数名不可重名，重名时需要获取Protocol对象显式调用
bookInfo.setRetry(2)
        .setTimeout(100)
        .setUrl('/getBookInfo')
        .setHeaders({
            'user-agent': 'yog-ral'
        });

bookInfo.call(function(err, data){
    //handle data and err
});
```

## 模块设计

### Config

Config模块用于处理配置解析以及BNS资源定位更新，考虑到Node.js的程序与PHP程序不同，程序更新必须要重启服务，因此暂不提供配置热加载能力。

Config配置使用Javascript Object来描述

```javascript
var config = {
    'bookService' : {
        retry : 1,
        timeout : 1000,
        unpack : 'json',
        //指定服务端交互的编码格式，由于Node.js环境只支持UTF-8，因此yog-ral会自动进行转码工作
        encoding : 'GBK',
        balance : 'random',
        protocol : 'http',
        server : [
            { host : 'st.yd.baidu.com', port : '80', idc : 'st'},
            { host : 'tc.yd.baidu.com', port : '80', idc : 'tc'},
            { ip : 'tc.yd.baidu.com', port : '80', idc : 'tc'},
        ]
    },
    'bookServiceBNS' : {
        retry : 1,
        timeout : 1000,
        unpack : 'json',
        encoding : 'GBK',
        balance : 'random',
        protocol : 'http',
        server : [
            { bns : 'wenku.backend.all'},
            //可选的备用服务器信息，启动时如果没能成功获取BNS信息，会使用备用服务器信息，如果没有备用信息则启动失败
            { host : 'st.yd.baidu.com', port : '80', idc : 'st'},
            { host : 'tc.yd.baidu.com', port : '80', idc : 'tc'}
        ]        
    },
    'bookListService' : {
        retry : 1,
        timeout : 500,
        //设置Request参数的打包协议
        pack : 'form',
        //设置Response的解包协议
        unpack : 'json',
        encoding : 'GBK',
        balance : 'random',
        protocol : 'http',
        //设置协议的默认参数，可被用户覆盖
        method : 'POST',
        url : '/book/list',
        headers : {
            'user-agent' : 'yog-ral'
        }
        server : [
            //由于不是所有上游服务均设置了TAG，BNS也支持设置idc
            { bns : 'wenku.backend.st', idc : 'st'},
            { bns : 'wenku.backend.tc', idc : 'tc'}
        ]
    },
    'bookListServiceWithCUI' : {
        retry : 1,
        timeout : 500,
        //converter等价设置unpack与pack均为mcpack
        converter : 'mcpack',
        encoding : 'GBK',
        balance : 'random',
        protocol : 'nshead',
        server : [
            { bns : 'wenku.backend.cui.all'}
        ]
    }
}
```

从性能考虑出发Config模块不会在每次服务获取时都重新获取BNS信息，因此需要一个BNS定时更新机制。从Node的异步事件机制以及BNS查询方法两方面来考虑，我们不需要与Ral一样使用独立进程来处理BNS查询问题。

```javascript
var spawn = require('child_process').spawn;
setInterval(function(){
    var get_instance = spawn('get_instance_by_service',[service,'-i','-p','-s','-l']);
}, 15000);
```

我们通过spawn调用，虽然在性能上不如原生代码优异，但是由于BNS的定时更新机制决定了我们的BNS更新性能要求并不严苛，使用spawn是完全可以接受的，并且降低了BNS更新的复杂性，即使崩溃也不会对Woker进程产生影响。

这种方案唯一问题在于每一个Worker均会独立进行BNS信息更新，这样会造成不必要的性能耗费，但是由于Worker间通信并不方便，只能采用文件锁的形式进行数据交换。考虑到get_instance_by_service本身的性能较高，查询时间在1ms-3ms内，因此暂时接受独立更新的设计，不进行文件数据交换的优化。

### Balance

Balance设计将会大量参考Ral的负载均衡与反馈机制，Ral的负载均衡设计可参考[Ral2设计文档](http://man.baidu.com/inf/odp/ral2/design/#负载均衡模块)。

初期我们将实现随即策略、轮询策略的负载均衡策略，可用性与负载强度的反馈机制将高优先级后续实现。

### Converter

Converter用于对解决客户端的数据格式与服务接口数据格式的异构问题，我们将实现json, raw, form, mcpack的数据编码解码服务。

```javascript
//@param data JSON Object
//@return Buffer
function pack(data)

//@param buffer Buffer
//@return JSON Object
function unpack(buffer)
```

Node.js下我们的问题在于Node字符串仅支持UTF8编码，并且一旦从Buffer按照UTF8编码进行转换后，就无法通过iconv重新转回正确编码了，因此我们必须要求Converter在处理编码问题时必须慎重，尽量保持使用Buffer传递数据。

此处设计有一个遗留问题是在HTTP协议的GET请求中，我们无法将querystring作为一种Converter实现，因而data => querystring的编码转换工作可能需要由协议来完成而不是Converter。

### Protocol

Protocol用于解决网络协议问题，我们将实现http与nshead两种网络协议。

协议接口如下

```javascript
function setRetry(retry) {}
function setTimeout(millsec) {}
function talk(request) {}
```

除了接口规定的函数外，各个协议还可以自行补充接口，所有的set接口均可以在rpc层穿透调用。

如HttpProtocol

```javascript
function setRetry(retry) {}
function setTimeout(millsec) {}
function talk(request) {}

function setUrl(url) {}
function setHeaders(headers) {}
function setUserAgent(userAgent) {}
function setReferer(referer) {}
```

其中所有set方法，都可以直接在相应的rpc服务内直接调用

```javascript
var dtd = rpc('bookService')
    .setMethod('GET')
    .setUrl('/bookList')
    .call();
```

在talk方法中，我们会调用Socket、HTTP、HTTPS网络协议来进行实际的网络请求，Request参数将提供写入的Header和Payload流。

与Ral不同之处在于，我们不使用各个网络协议自身的超时机制，不提供连接、写入、读取超时支持，仅提供粗粒度的整体timeout能力，方便FE理解。因此超时处理可以在不在Protocol模块处理，而在后续的RPC模块中处理。

### RPC

RPC是整个系统的主控模块，他的主要职责有

1. 定时调用Config模块的BNS更新功能
2. 根据指定服务名获取服务，并初始化相应的Balance、Converter、Protocol
3. 调用Config与Balance获取服务实例
4. 调用Converter包装客户端输入，解包服务端输出
5. 调用Protocol进行远程请求，处理超时重试机制

引用一张Ral2的流程图，yog-ral的处理流程与其保持一致。

![](rpc_data_flow.png)
