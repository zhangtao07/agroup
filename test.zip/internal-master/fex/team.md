FEX 成员概况
========

汇总 FEX 成员信息，方便开展人力规划。  

部门邮件 <fex@baidu.com>

## Leader

#### 刘平川

* github <https://github.com/ranklau>
* blog <http://rank.im/>
* weibo <http://weibo.com/rank>
* email <liupingchuan02@baidu.com>

## FIS

**现役：6人**  
**负责人：相守鼎**  

#### 相守鼎

* github <https://github.com/xiangshouding>
* weibo <http://weibo.com/fansekey>
* email <xiangshouding@baidu.com>

#### 何方石

* github <https://github.com/hefangshi>
* email <hefangshi@baidu.com>

#### 张涛

* github <https://github.com/zhangtao07>
* weibo <http://weibo.com/u/1733215473>
* email <zhangtao07@baidu.com>

#### 王程

* github <https://github.com/wangcheng714>
* weibo <http://weibo.com/wang00cheng>
* email <wangcheng@baidu.com>

#### 廖学芝

* github <https://github.com/2betop>
* weibo <http://weibo.com/u/1879042664>
* email <liaoxuezhi@baidu.com>

#### 张莹

* github <https://github.com/lily-zhangying>
* weibo <http://weibo.com/u/1398667565>
* email <zhangying05@baidu.com>

**退役**  

#### 沈洪顺 2014.09 转至移动云

* github <https://github.com/walterShen>
* weibo <http://weibo.com/u/1916384703>
* email <shenhongshun@baidu.com>

## 数据

小组邮箱 <dp@baidu.com>

**现役：6人**  

#### 张军

* github <https://github.com/zhangjunah>
* weibo <http://weibo.com/zhangjunah>
* email <zhangjun08@baidu.com>

#### 杜鸿斌 - 实习

* github <https://gibhub.com/kevindu1993>
* email <duhongbin01@baidu.com>

#### 杜明坦

* github <https://github.com/the1sky>
* blog <http://rialive.com/>
* weibo <http://weibo.com/nant>
* email <dumingtan@baidu.com>

#### 吴多益

* github <https://github.com/nwind>
* blog <http://wuduoyi.com/>
* weibo <http://weibo.com/nwind>
* email <wuduoyi@baidu.com>

#### 牛尧

* github <https://github.com/zenany>
* weibo <http://weibo.com/paleswd>
* email <niuyao@baidu.com>

#### 赵爽：在 sep 学习用户数据分析  

* github <https://github.com/JohnYY>
* weibo <http://weibo.com/u/1790395525>
* email <zhaoshuang@baidu.com>

**退役：**

#### 陆俊哲：2014年7月被老婆叫回杭州

* github <https://github.com/Singularity-zju>
* email <lujunzhe01@baidu.com>

#### 张晓亮：2014年6月转至移动端新产品  

* weibo <http://weibo.com/larryzh>
* email <zhangxiaoliang01@baidu.com> larryisthere@gmail.com
* github https://github.com/larryisthere

#### 雷毅：2014年04月退役

* github <https://github.com/measy>
* weibo <http://weibo.com/measy/>

## 复杂应用

**现役：9人**  
**子方向：** 在线办公 & 数据可视化

#### 战毅 - 总负责人

* github <https://github.com/campaign>
* weibo <http://weibo.com/u/1721507145>

#### 王集鹄 - 技术负责人

* github <https://github.com/zswang>
* blog <http://blog.csdn.net/zswang>
* weibo <http://weibo.com/zswang>
* email <wangjihu@baidu.com>

#### 刘家鸣

* github <https://github.com/techird>
* blog <http://techird.com>
* weibo <http://weibo.com/techird>
* email <liujiaming@baidu.com>

#### 韩聪

* github <https://github.com/HanCong03>
* email <hancong03@baidu.com>

#### 张可竞

* github <https://github.com/ronnyKJ>
* weibo <http://weibo.com/ronnykj>
* email <zhangkejing02@baidu.com>

#### 许金泉

* github <https://github.com/Jinqn>
* email <xujinquan@baidu.com>

#### 潘征  

* github <https://github.com/Akikonata>
* weibo <http://weibo.com/u/1698334494>
* email <panzheng@baidu.com>

#### 杨小湖 - 实习

* github <https://gibhub.com/yangxiaohu2014>
* email <yangxiaohu@baidu.com>

#### 张博 - 实习

* github <https://gibhub.com/zhangbobell>
* blog <http://zhangbobell.cn>
* weibo <http://weibo.com/zhangbobell>
* email <zhangbobell@163.com>

## 端技术

小组邮箱 <end@baidu.com>
合作项目 <fex-bridge@baidu.com>

**现役：5人，创新探索性小组**

#### 陈敏亮 - 负责人

* github <https://github.com/miller>
* blog <http://milleris.me/>
* email <chenminliang01@baidu.com>

#### 张自萌

* github <https://github.com/zimengle>
* email <zhangzimeng01@baidu.com>
* weibo <http://weibo.com/shuaizaole>

#### 张宁

* home <http://besideriver.com/>
* github <https://github.com/zhang-ning>
* email <zhangning09@baidu.com>

#### 刘道-校招

* github <https://github.com/7xnoap>
* email <liudao@baidu.com>

#### 王知良-实习

* home <http://jalons.me>
* github <https://github.com/jalonjs>
* email <wangzhiliang03@baidu.com>

**退役：**

#### 艾心-实习：2014.09 回校

* github <https://github.com/cyndix33>
* email <aixin@baidu.com>

#### 张佳辰：2014.09 回杭州

* github <https://github.com/zjcqoo>
* weibo <http://weibo.com/etherdream>
* blog <http://www.cnblogs.com/index-html>
* email <zhangjiachen@baidu.com>

#### 李鹏展：2014.07 回成都

* github <https://github.com/pengzhanlee>
* blog <http://www.jsmix.com>
* email <lipengzhan@baidu.com>

#### 赵成阳：2014年6月转至上海公有云团队  

* github <https://github.com/jianling>
* weibo <http://weibo.com/chengyoung>
* email <zhaochengyang@baidu.com>

## 待入职

