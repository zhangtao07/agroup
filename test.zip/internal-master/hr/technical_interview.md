面试
========

  面试过程中需要考察后续人的技术、软素质、潜力是否符合要求。  
  面试共分三轮，下边将介绍每轮的重点考察项目。  
  自驱、潜力是我们最看重的。  
  
  面试考察点及面试题的细节，请参考： **[FEX 面试评估表](doc/fex_tech_interview_template.xlsx)** 。  

## 经验汇总

可取经的面试高手：

- 一面&二面：多益、集鹄
- 三面：平川

案例分享：

- [三面案例](interview-demo.md)

## 面试评估项&参考题目

- [一面](the-first-interview.md)
- [二面](the-second-interview.md)
- [三面](the-third-interview.md)

## 面试参考

- [Amazon 前技术副总裁解剖完美技术面试](http://www.36kr.com/p/210076.html)
- [STAR 面试法](http://baike.baidu.com/view/1887275.htm)
- [Front end Developer Interview Questions](https://github.com/darcyclarke/Front-end-Developer-Interview-Questions)  
- [轻松面试找到理想员工－非官方的面试技术指南](http://chinese.joelonsoftware.com/Articles/Interviewing.html)  















