FEX 黑魔法
====

## 开发环境

墙是生活的一部分，如果 npm 不能安装插件，那这个技能就要注意了

### NPM

```
## 国内代理，这个真是墙
$npm config set registry http://registry.cnpmjs.org/

## 内网代理，适合开发机上使用
$npm config set registry http://npm.internal.baidu.com/
```

## MAC 下使用 VPN 要注意

如果使用 `Cisco AnyConnect Secure Mobility Client` 在安装的时候要注意，不要开启 “Web Security” 选项，否则内网 SVN 不能正常获取 [参考链接](http://www.thebitguru.com/blog/view/394-Random%20Slowdown%20of%20Browsers%20in%20OS%20X%20Mountain%20Lion)

