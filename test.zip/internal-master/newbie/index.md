FEX 新人指南
========

## 新人报道

1. 导师带着介绍部门同事
    * 先混个眼熟
1. 配置无线网络
    * PC/Mac 连 Baidu，密码 `zhonglixuntaqianbaidu&1999`
        * PC/MAC [准入下载](http://zhunru.baidu.com/) 没有准入不能进入内网
    * iOS/Android 连 Baidu_wifi，使用邮箱帐号密码
1. Hi（<http://web.im.baidu.com/>）
    * 使用百度账号登录，如果没有先去注册一个百度帐号
    * Mac 版 Hi [App Store](http://itunes.apple.com/cn/app/bai-duhi/id537923517)
    * 加入 FEX hi 群（1417433）
    * 加入 WebFE hi 群（1394982）
1. 邮箱（<http://email.baidu.com>）
    * 每个平台不太一样，建议使用 Exchange 方式，域填 `internal.baidu.com` 方便获得联系人列表
    * 发邮件给 webfe@baidu.com 介绍自己

## 工作环境搭建

1. 配置 token
1. FE 开发机
    1. 发邮件给 wuduoyi@baidu.com 申请 FE 开发机帐号，需提供邮箱前缀来作为用户名
    1. 通过 Relay 登录 fe/fedev 机器 ，你可以先了解一下 [什么是Relay](relay.text)
    1. 使用 Samba 方便访问
1. SVN 权限，找导师在 iCafe 上 「产品管理」->「申请角色」

## 阅读文档

* 看公司[新员工指南](http://babel.baidu.com/xyg.html)，了解公司文化
* 在 [FEX 官网](http://fex.baidu.com/)上打开各个 topic 的主页，了解工作内容，尤其是自己目前所在 Topic
* 看多益分享的《工程师的个人发展规划》：[视频](http://learn.baidu.com/courseInfo.html?courseId=2831)、[PPT](https://speakerdeck.com/baidufe/gong-cheng-shi-de-ge-ren-fa-zhan-gui-hua)

## 导师沟通

内容包括但不限于：

* 介绍 FEX 整体情况
* 新人询问 FEX 对各个 Topic 的了解情
* 详细介绍新人目前所在 Topic 的细节情况
* 新人个人情况了解
* 制订试用期计划，导师需要根据新人的特点来

## 其它信息

* 每个员工每个月可以领取办公用品，你可以到 [在线领取](http://family.baidu.com/core/index.jsp?chc=1264304703) 上进行登记后等客服送到，也可以直接去办公用品中心(文思一楼东南角)去领取.
* 办公楼信息请阅读[文思海辉办公区办公指南](文思海辉办公区办公指南.pptx)，里面包括办公用品等各种信息
* 用 [lync](http://ite.baidu.com/) 打电话
* 打印机（只支持 Windows 系统, Mac用户可以通过运行虚拟机来打印）
    * 在运行中输入 `\\172.22.2.19`，用户名`internal\xxx`，其中 xxx 是邮箱前缀，密码是邮箱密码，双击 `Input BW Printer` 就行了
    * 先按下打印机的 ON/OFF 键，然后在读卡器上刷卡
* 买书去这里[申购](http://st.baidu.com/bbs/plugin.php?identifier=book&module=book&action=order)，目前没有限制
* 部门助理目前是 赵新杰(Hi: xinjie686) ，不过助理MM目前怀孕了，需要搬运之类的事情就还是自己去做吧。
* 会议室预订可以在 family 上，每天10点30分开始预定，可以预订到下一周的。前往 [预定会议室](http://family.baidu.com/core/index.jsp?chc=-1086609825)进行预定即可。 每次会议开始的时候，记得一定要去[签到会议室](http://meeting.baidu.com/web/scheduleList),否则会被列入黑名单。你也可以通过安装[移动办公APP](http://moa.baidu.com)来进行签到.


## 部门的相关网站

+ 部门对外官网 [http://fex.baidu.com/](http://fex.baidu.com/)
+ 部门对内主页 [http://fex-team.baidu.com/](http://fex-team.baidu.com/)
+ 文档 [http://fe.baidu.com/](http://fe.baidu.com/)
+ FEDay [http://fex.baidu.com/feday/](http://fex.baidu.com/feday/)
+ webspeed [http://webspeed.baidu.com/](http://webspeed.baidu.com/)
+ UEditor [http://ueditor.baidu.com/](http://ueditor.baidu.com/)
+ Hunter [http://hunter.baidu.com/](http://hunter.baidu.com/)
+ GMU [http://gmu.baidu.com/](http://gmu.baidu.com/)
+ FIS [外网](http://fis.baidu.com/) [内网](http://fe.baidu.com/fis/) 

## 内网其它资源

* [FE 官网](http://fe.baidu.com/)，有很多其它部门 FE 的主页
* [河图](http://hetu.baidu.com/api/php/index)，公司其它部门的平台及工具
* [babel](http://babel.baidu.com/)，有不懂的名词可以先在这里搜索


