# Mac 环境配置打印机

* from: <http://ask.babel.baidu.com/question/4985.html>
* http://docs.babel.baidu.com/doc/0eedbe52-83fb-49a1-a919-92239b4172ec?isPreviewAll=true

## 加域

	系统偏好设置 ->
	用户与群组 ->
	登陆选项 ->
	网络帐户服务器 ->
	打开目录实用工具 ->
	Active Directory -> 
	域：internal.baidu.com 

## 下载安装打印机驱动

[打印机驱动下载](http://support-cn.canon-asia.com/contents/CN/ZH/0100491601.html)

## 添加打印机

	系统偏好设置 ->
	打印机与扫描仪 ->
	点击左下角【+】->
	按住 control 鼠标点击窗口顶部的空白  ->
	自定义工具栏 ->
	把高级拽到之前窗口的顶部 ->
	完成 -> 
	高级 -> 
	类型：Windows printer via spoolss -> 
	URL添smb://172.22.2.19/Input%20BW%20Printer  -> 
	名称随便 -> 
	使用 选择软件 -> 
	Canon IR2830 ->  
	添加
