翻墙指南
========

## 背景

不解释，另外通过代理可以让 github 访问速度快很多。

## GFW 是如何工作的

推荐阅读维基百科的[防火长城](http://zh.wikipedia.org/wiki/%E9%98%B2%E7%81%AB%E9%95%BF%E5%9F%8E)词条

### DNS 污染

GFW 如果发现你请求了黑名单的域名，就马上给你返回一个不正确的 ip 地址，如下

```
; <<>> DiG 9.8.3-P1 <<>> +trace facebook.com
;; global options: +cmd
.           218547  IN  NS  a.root-servers.net.
.           218547  IN  NS  e.root-servers.net.
.           218547  IN  NS  i.root-servers.net.
.           218547  IN  NS  d.root-servers.net.
.           218547  IN  NS  b.root-servers.net.
.           218547  IN  NS  m.root-servers.net.
.           218547  IN  NS  c.root-servers.net.
.           218547  IN  NS  f.root-servers.net.
.           218547  IN  NS  h.root-servers.net.
.           218547  IN  NS  k.root-servers.net.
.           218547  IN  NS  g.root-servers.net.
.           218547  IN  NS  j.root-servers.net.
.           218547  IN  NS  l.root-servers.net.
;; Received 492 bytes from 172.22.1.253#53(172.22.1.253) in 2035 ms

facebook.com.       300 IN  A   59.24.3.173
;; Received 46 bytes from 192.112.36.4#53(192.112.36.4) in 41 ms
```

### 

## 翻墙服务

### 公司的 HTTP 代理

只能在公司内部使用，地址：172.19.1.2，端口：9217。

### Shadowsocks

注意，这是友情提供的 Shadowsocks，这是公司一位同事买的日本 Linode，我有服务器 root 权限，大家不用担心被偷窥，但仅供内部使用，**禁止共享给其他部门或朋友**，请自觉遵守。

安装 [shadowsocks-nodejs](https://github.com/clowwindy/shadowsocks-nodejs)，可以通过 npm 安装

创建配置文件 `config.json` 内容为如下

```
{
    "server": "106.186.23.103",
    "server_port": 8123,
    "local_port": 1081,
    "password": "fex2014",
    "timeout": 600,
    "method": "aes-256-cfb"
}
```

或者这个

```
{
    "server": "106.187.89.52",
    "server_port": 443,
    "local_port": 1081,
    "password": "MhxzKhl",
    "timeout": 30,
    "method": "aes-256-cfb"
}
```

然后在这个目录下运行 sslocal 命令，看到如下提示

```
28 Apr 17:24:14 - 412ms loading config from config.json
28 Apr 17:24:14 - 419ms UDP server listening 127.0.0.1:1081
28 Apr 17:24:14 - 420ms local listening at 127.0.0.1:1081
```

这是一个 SOCKS v5 的代理，具体设置请参考下面的 Chrome 章节

另外，可以使用 polipo 将 socks 代理转成 HTTP 代理，在 mac 可以通过 `brew install polipo` 安装，具体使用方法是运行 `polipo socksParentProxy=localhost:1081` 命令，然后会出现提示，如 `Established listening socket on port 8123.`，这样就能使用 `127.0.0.1:8123` 作为 HTTP 代理了

### go-agent

附上我的 go-agent 的 appid，其它同学有的话可以补充：

```
wfg-nwind|nwind-proxy|nwind-cloud
```

### 忽略 TCP reset

通过内核忽略 TCP reset，就能彻底免受连接重置的问题

linux 下使用 iptables 命令

    sudo iptables -A INPUT -p tcp --tcp-flags RST RST -j DROP

mac 下使用 ipfw 命令

    sudo ipfw add 1000 drop tcp from any to me tcpflags rst in

## 不同平台下的做法

### Chrome

使用 SwitchySharp 插件，这里只介绍 SOCKS v5 代理的设置，如下

![](./wfg/switchysharp.png)

目前 GFW 封掉太多域名了，所以我采用的是白名单机制，参考上图中的 No Proxy for，以下基于 killwall 的白名单添加了几个网站：

```
*org.ezproxy.its.uu.se*;*.csdn.net;*kanxue.com;*jd.com*;172.22.*;localhost;127.0.0.1;<local>;*.maiyadi.com;17ce.com;*.60in.com;*pnso.com;*omezz.com;*.cn;221.3.136.7;*192.168.;*zijieshe.com;*yuncheng.com;*42.121.109.141;*6.cn;*dianru.com;*10.;*172.1;*172.2;*172.3;*xuanpg.com;*cydia.saurik.com;*path.com;*instagram.com;*icloud.com;*tbcdn.cn;*behe.com;*imanhua.com;*duomi.com;*qiyi.com;*edu.cn;*qq.com;*3322.org;*amap.com;*gao7.com;*yyets.com;*211.151.133.180;*211.1.133.180;*weibo.com;*pplive.com;*baidupcs.com;*renren.com;*taobao.com;*localhost;*127.0.0.1;*baidu.com;*163.com;*xueqiu.com;*taobaocdn.com;*mzstatic.com;*hi-pda.com;*wallproxy.com;*360buyimg.com;*126.net;*upaiyun.com;*ucweb.com;*pptv.com;*douban.com;*dianping.com;*dpfile.com;*360buy.com;*doubleclick.net;*weiphone.com;*rrimg.com;*cnzz.com;*yupoo.com;*cnbeta.com;*mapabc.com;*alipay.com;*netease.com;*10010.com;*umeng.com;*weico.cc;*zhimg.com;*25pp.com;*jiepang.com;*pcbeta.com;*feedsky.com;*images-amazon.com;*duowan.com;*immomo.com;*mmstat.com;*178.com;*360.cn;*zhihu.com;*saodong.info;*youku.com;*v2ex.com;*ppstv.com;*21cn.com;*xunlei.com;*sohu.com;*dgtle.com;*changba.com;*tangcha.tc;*gfan.com;*guohead.com;*zubunet.com;*iapps.im;*guokr.com;*smzdm.com;*ifanr.com;*tongbu.com;*hupan.com;*gtimg.com;*ijinshan.com;*xiami.com;*bdimg.com;*admob.com;*duapp.com;*qiushibaike.com;*atpanel.com;*cmbchina.com;*go2map.com;*xcarimg.com;*xiaomi.net;*adsage.com;*95105888.com;*xnpic.com;*youdao.com;*tgfcer.com;*jie.pn;*sinaapp.com;*xiamentd.com;*wandafilm.com;*mtime.com;*wumii.com;*myzaker.com;*2500city.com;*mydigit.net;*hexun.com;*imp3.net;*genmiao.com;*variflight.com;*hupu.com;*huofar.com;*ykimg.com;*alimama.com;*baihe.com;*kugou.com;*ddmapimg.com;*rrfmn.com;*getqujing.com;*iweek.ly;*qunar.com;*itings.com;*huanqiu.com;*edoctorsh.com;*tanx.com;*yimg.com;*linezing.com;*googlesyndication.com;*test3g.com;*vcread.com;*verylohas.com;*alisoft.com;*tencent.com;*9sky.com;*gaopeng.com;*tgbus.com;*iweeklyapp.com;*meituan.net;*infothinker.com;*alicdn.com;*moji001.com;*56img.com;*kblcc.com;*ddmap.com;*mindmeters.com;*vanclimg.com;*caixin.com;*aliyun.com;*eoeandroid.com;*36kr.com;*blogbus.com;*aibang.com;*ngacn.cc;*51yes.com;*vpon.com;*xiachufang.com;*alipayobjects.com;*tudou.com;*dataidi.com;*douguo.com;*ipv6edu.com;*vcimg.com;*sogou.com;*jmstatic.com;*ydstatic.com;*cutt.com;*ppurl.com;*songshuhui.net;*dashuye.com;*tech2ipo.com;*baby-edu.com;*gewara.com;*liqucn.com;*padest.com;*yaolan.com;*paoxue.com;*imofan.com;*imanhua.com;*ikea.com;*meituan.com;*googleadservices.com;*36krcnd.com;*xiaoenai.com;*zzbtv.com;*ishwap.com;*tmall.com;*huxiu.com;*kdnet.net;*tuan800.com;*xitek.com;*chinaevent.org;*adobe.com;*kaixin001.com;*adsmogo.org;*95526.mobi;*taihainet.com;*zghzp.com;*2hua.com;*51buy.com;*88210212.com;*jiathis.com;*sdo.com;*gwdang.com;*pjtime.com;*tdimg.com;*soufun.com;*dospy.com;*huaban.com;*ttpod.com;*vdisk.me;*zuchecdn.com;*2000tuan.com;*anytimetomail.com;*letao.com;*51.la;*bundpic.com;*hdstar.org;*jiayuan.com;*admin5.com;*aicdn.com;*ujian.cc;*cnhan.com;*cztv.com;*dbank.com;*kximg.cc;*2500sz.com;*zuche.com;*360doc.com;*guang.com;*iask.com;*it168.com;*wangpiao.com;*yeshj.com;*thinkorz.com;*wali.com;*cdn123.net;*u148.net;*letv.com;*51mdq.com;*qbox.me;*battle.net;*hujiang.com;*huohua.tv;*iyaya.info;*kowtime.com;*rockbundartmuseum.org;*snssdk.com;*walizip.com;*allyes.com;*suning.com;*sz-map.com;*wochacha.com;*feidee.com;*oeeee.com;*52miji.com;*gcimg.net;*app-sage.com;*appdp.com;*camcard.com;*koudai.com;*libdd.com;*yahoo.com;*aibangjuxin.com;*cnblogs.com;*iguanzhong.com;*tower.im;*city8.com;*geekpark.net;*img168.net;*moji002.com;*damndigital.com;*ebookcn.com;*nbweekly.com;*wisesz.com;*guoku.com;*shencai.cc;*dm456.com;*kuaidi100.com;*artlinkart.com;*fanfou.com;*pro-preview.com;*wxcsgd.com;*xianguo.com;*downmyneed.com;*funinput.com;*mangafiles.com;*sdg-china.com;*2cto.com;*cebbank.com;*itouchchina.com;*ruby-china.org;*soso.com;*toodaylab.com;*yy.com;*appinn.com;*rologo.com;*wrating.com;*youmi.net;*ibeike.com;*lieyingjiaxiao.com;*lmmob.com;*tangsuanradio.com;*uc123.com;*dmdelivery.com;*doc88.com;*icson.com;*manmanbuy.com;*stage1st.com;*a9vg.com;*360xh.com;*autonavi.com;*hudong.com;*outfit7.com;*umeng.co;*5d6d.net;*acfun.tv;*chewen.com;*ci123.com;*intsig.net;*elong.com;*fun-guide.mobi;*qiyou.com;*usa-merk.com;*115.com;*bdstatic.com;*infzm.com;*qiyipic.com;*126.com;*3conline.com;*ceming.com;*cfanhome.com;*cngba.com;*luo.bo;*mobmore.com;*wuxiapptec.com;*xgres.com;*zzjoy.com;*buytong.com;*dolphin-browser.com;*dongxi.net;*hostuc.com;*leiphone.com;*ssl-images-amazon.com;*yeeyan.com;*5d6d.org;*jyimg.com;*tianyaui.com;*vipshop.com;*bababian.com;*bbkz.net;*hdslb.com;*hiido.com;*miaozhen.com;*puata.info;*qqmail.com;*qycn.com;*tankr.net;*xiaonei.com;*blogcn.com;*chinaunix.net;*eicodesign.com;*geilicdn.com;*meitudata.com;*soufunimg.com;*91.com;*ali213.net;*cardcmb.com;*ed200.com;*127.net;*973.com;*burl.cc;*diandian.com;*guao.hk;*jeehui.net;*kk3g.net;*tuan800.net;*yizhedian.com;*5d6d.com;*baifendian.com;*bwchinese.com;*cnepub.com;*imrworldwide.com;*ip138.com;*opera-mini.net;*ppstream.com;*sheji.com;*vmall.com;*37cs.com;*amazon.com;*bokee.com;*elongstatic.com;*goalhi.com;*yeeyan.org;*alibaba.com;*idzoom.com;*ireadercity.com;*sc518.com;*seckungfu.com;*yinxiang.com;*zol-img.com;*56.com;*buyneed.com;*adsame.com;*ajiang.net;*jiongji.com;*nddaily.com;*vonibo.com;*yahooapis.com;*docin.com;*iplaysoft.com;*liebiao.com;*phpwind.com;*shupeng.com;*soomal.com;*tongcard.net;*yunyun.com;*777wyx.com;*99bill.com;*cnrvoice.com;*gaszx.com;*juhead.com;*nuomi.com;*pstatp.com;*zhangguibang.com;*zuoche.com;*91rb.com;*abchina.com;*chinauma.net;*cmread.com;*googletagservices.com;*mogujie.com;*mygolbs.com;*sinastorage.com;*xinhuanet.com;*51240.com;*70man.com;*apptao.com;*blogbuscdn.com;*csair.com;*duoshuo.com;*icebin.net;*kandian.com;*phpwind.net;*southcn.com;*wanlibo.com;*xmtcb.com;*70e.com;*acs86.com;*adsmogo.com;*dapenti.com;*easytimetv.com;*ixpub.net;*iyaya.com;*mapbar.com;*meitu.com;*rsscc.com;*sf-express.com;*wechatapp.com;*5dxc.com;*969g.com;*dmdeliver.com;*etuan.com;*gamerboom.com;*huitongke.com;*pj4mac.com;*playhaven.com;*sandai.net;*tigerknows.net;*vancl.com;*webscache.com;*2599tv.com;*dangdang.com;*ditiezu.com;*emailcar2.com;*ftimg.net;*gtags.net;*oadz.com;*rtbidder.net;*uyunad.com;*baidustatic.com;*chinanews.com;*daysmatter.com;*fengyunzhibo.com;*gomumu.mobi;*greencompute.org;*haodou.com;*heima8.com;*kandianshi.com;*movo.tv;*proarchinc.com;*qunarzz.com;*synacast.com;*xianggeapp.com;*54114.com;*adobe-dcfs.com;*alibuybuy.com;*csdn.net;*eastmoney.com;*gamecenternow.com;*jinsitu.com;*lettv.com;*pcpop.com;*qianqian.com;*speedtest.net;*ping-test.net;*mobilespeedtest.com;*rushplayer.com;*tenoad.com;*uctrac.com;*wandoujia.com;*xiezhua.com;*yihaodian.com;*123cha.com;*dianxin.com;*discoverhongkong.com;*gogoqq.com;*ihandysoft.com;*ku6img.com;*mmbang.com;*mmmppp333.com;*paipai.com;*palmtrends.com;*qingtingfm.com;*sharewithu.com;*soku.com;*tu265.com;*xiami.net;*zx915.com;*ifeng.com;*hao123.com;*chinaz.com;*pengyou.com;*58.com;*bing.com;*iqiyi.com;*ku6.com;*aizhan.com;*4399.com;*yesky.com;*ganji.com;*mop.com;*51job.com;*2345.com;*arpg2.com;*39.net;*twcczhu.com;*microsoft.com;*pchome.net;*zhaopin.com;*apple.com;*bitauto.com;*blog.163.com;*52pk.net;*baixing.com;*iteye.com;*verycd.com;*discuz.net;*7k7k.com;*msn.com;*ccb.com;*hc360.com;*51.com;*yoka.com;*seowhy.com;*chinabyte.com;*qidian.com;*ctrip.com;*tom.com;*tenpay.com;*120ask.com;*yahoo.co.jp;*ebay.com;*51cto.com;*meilishuo.com;*17173.com;*xyxy.net;*19lou.com;*yiqifa.com;*eastday.com;*onlinedown.net;*oschina.net;*zhubajie.com;*babytree.com;*qq937.com;*nipic.com;*im286.com;*baomihua.com;*doubleclick.com;*dh818.com;*ads8.com;*hiapk.com;*ynet.com;*sootoo.com;*a135.net;*lashou.com;*crsky.com;*iciba.com;*uuzu.com;*haodf.com;*youboy.com;*ulink.cc;*88db.com;*tao123.com;*yolk7.com;*tiexue.net;*stockstar.com;*xici.net;*linkedin.com;*shangdu.com;*aili.com;*anjuke.com;*cnxad.com;*west263.com;*gougou.com;*whlongda.com;*mnwan.com;*onetad.com;*duote.com;*55bbs.com;*iloveyouxi.com;*gongchang.com;*meishichina.com;*qire123.com;*55tuan.com;*cocoren.com;*xiaomi.com;*thethirdmedia.com;*coo8.com;*aliexpress.com;*onlylady.com;*manzuo.com;*3366.com;*28tui.com;*1616.net;*pp.cc;*jumei.com;*tui18.com;*52tlbb.com;*yinyuetai.com;*eye.rs;*lusongsong.com;*leho.com;*315che.com;*donews.com;*cqnews.net;*591hx.com;*114la.com;*gamersky.com;*tangdou.com;*uuu9.com;*xinnet.com;*dedecms.com;*cnmo.com;*51fanli.com;*lady8844.com;*newsmth.net;*ucjoy.com;*duba.net;*cnki.net;*funshion.com;*qjy168.com;*paypal.com;*3dmgame.com;*m18.com;*53kf.com;*makepolo.com;*5173.com;*vjia.com;*hotsales.net;*4738.com;*mydrivers.com;*titan24.com;*u17.com;*jb51.net;*dzwww.com;*hichina.com;*abang.com;*qianlong.com;*m1905.com;*chinahr.com;*zhaodao123.com;*aqi.com;*fobshanghai.com;*q150.com;*l99.com;*ccidnet.com;*aifang.com;*aol.com;*theplanet.com;*hf365.com;*ad1111.com;*blueidea.com;*net114.com;*07073.com;*alivv.com;*mplife.com;*jqw.com;*1ting.com;*yougou.com;*made-in-china.com;*zoosnet.net;*exam8.com;*jxedt.com;*uniontoufang.com;*zqgame.com;*52kmh.com;*yxlady.com;*sznews.com;*longhoo.net;*game3737.com;*51auto.com;*booksky.org;*iqilu.com;*cncn.com;*ename.net;*1778.com;*blogchina.com;*778669.com;*dayoo.com;*ct10000.com;*zhibo8.cc;*qingdaonews.com;*zongheng.com;*1o26.com;*tiancity.com;*jinti.com;*si.kz;*tuniu.com;*gamestlbb.com;*moonbasa.com;*ztgame.com;*kimiss.com;*cnhubei.com;*pingan.com;*lafaso.com;*rakuten.co.jp;*zhenai.com;*tiao8.info;*7c.com;*tianji.com;*house365.com;*flickr.com;*xiazaiba.com;*sodu.org;*bankcomm.com;*lietou.com;*toocle.com;*fengniao.com;*bendibao.com;*nowec.com;*yingjiesheng.com;*comsenz.com;*meilele.com;*otwan.com;*61.com;*meizu.com;*readnovel.com;*fenzhi.com;*up2c.com;*500wan.com;*fx120.net;*ftuan.com;*17u.com;*lehecai.com;*28.com;*bilibili.tv;*szhome.com;*miercn.com;*fblife.com;*chinaw3.com;*b2b168.com;*265g.com;*anzhi.com;*chuangelm.com;*php100.com;*100ye.com;*hefei.cc;*mumayi.com;*nstagram.com;0bad.com;*toryday.com;ihongpan.com;killwall.com;*chiphell.com;jandan.net;ttmeiju.com;simplecd.me;*ele.me;*zueiai.net;*vpsee.com;*ikang.com;*.homezz.net;*mailion.net;*blueionic.com;*unionpay.com;*unionpaysecure.com;*chinaunionpay.com;*188.com;*kuaipandata.com;*mi-img.com;*miui.com;*flyertea.com;*easternmiles.com;*hnair.com;*travelsky.com;*qfpay.com;*iboxpay.com;*isicchina.com;*elvxing.net;*lakala.com;*qyer.com;*yhachina.com;*hipiao.com;*piaolala.com;*feemii.com;*cdqcp.com;*nanrenwa.com;*51dyt.com;*dianying.fm;*ahlwsp.com;*shanbay.com;*ganji.com;*pediy.com;*jumbo.ws
```

### Mac/Linux 命令行

可以有以下 2 种方法

* 设置 http_proxy 环境变量
    
    ```
    export http_proxy=http://localhost:8123
    export https_proxy=http://localhost:8123
    ```

* 通过 proxychains 来运行命令
    * 这种方式可以在执行某个命令时使用代理，很方便，如 `proxychains4 git pull`
    * mac 下可以通过 `brew  install proxychains-ng` 安装，然后编辑 `~/.proxychains/proxychains.conf` 文件，最底部加上如下配置

        ```
        strict_chain

        proxy_dns 

        remote_dns_subnet 224

        tcp_read_time_out 15000

        tcp_connect_time_out 8000

        localnet 127.0.0.0/255.0.0.0

        [ProxyList]
        socks5  127.0.0.1 1081
        ```

### Android

可以安装[影梭](https://play.google.com/store/apps/details?id=com.github.shadowsocks)，相关配置参考前面的 shadowsocks。

### iOS

我目前使用 vpnso.com，不过需要注意这种第三方 VPN 能拿到你的所有浏览数据，少用为好。

### Windows

安装 [Shadowsocks GUI](http://pan.baidu.com/s/1c0F4hZq) ，参照前文的 shadowsocks 配置即可。
