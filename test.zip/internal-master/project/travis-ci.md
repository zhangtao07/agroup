持续集成工具 travis-ci
==============================

为了提升项目质量，后续 FEX 在 github 上的项目都需要接入 https://travis-ci.org 来进行自动化的单元测试和规范检查。

## 目录
* [什么是 travis-ci？](#%E4%BB%80%E4%B9%88%E6%98%AF-travis-ci)
* [如何接入？](#%E5%A6%82%E4%BD%95%E6%8E%A5%E5%85%A5)
* [.travis.yml 详情](#travisyml-%E8%AF%A6%E6%83%85)
* [执行脚本](#执行脚本)
* [单元测试](#单元测试)
* [规范检查](#规范检查)

## 什么是 travis-ci？

[Travis CI](http://travis-ci.org/) 是在软件开发领域中的一个在线的，分布式的持续集成服务，用来构建及测试在 [GitHub](https://github.com/) 托管的代码。

它提供了多种编程语言的支持，包括 [C](http://docs.travis-ci.com/user/languages/c)，[C++](http://docs.travis-ci.com/user/languages/cpp)，[Clojure](http://docs.travis-ci.com/user/languages/clojure)，[Erlang](http://docs.travis-ci.com/user/languages/erlang)，[Go](http://docs.travis-ci.com/user/languages/go)，[Groovy](http://docs.travis-ci.com/user/languages/groovy)，[Haskell](http://docs.travis-ci.com/user/languages/haskell)，[Java](http://docs.travis-ci.com/user/languages/java)，[JavaScript (with Node.js)
](http://docs.travis-ci.com/user/languages/javascript-with-nodejs)，[Objective-C](http://docs.travis-ci.com/user/languages/objective-c)，[Perl](http://docs.travis-ci.com/user/languages/perl)，[PHP](http://docs.travis-ci.com/user/languages/php)，[Python](http://docs.travis-ci.com/user/languages/python)，[Ruby](http://docs.travis-ci.com/user/languages/ruby) 和 [Scala
](http://docs.travis-ci.com/user/languages/scala) 在内的多种语言。许多知名的开源项目使用它来在每次提交的时候进行构建测试，比如 Ruby on Rails，Ruby 和 Node.js。

## 如何接入？

1. 用 [GitHub](https://github.com/) 帐号登陆 [Travis CI](http://travis-ci.org/)，然后在 [profile](https://travis-ci.org/profile) 页面会列出所有公开的项目。
2. 在列表中点开你想开起的项目。

    ![flip switch](./travis-ci/list.png)
3. 在仓库的根目录添加 `.travis.yml` 文件。

    不同语言的项目，`.travis.yml` 文件配置不一样。

    以下是一些常用语言的实例：

    **Java**

    ```yml
    language: java
    jdk:
      - oraclejdk7
      - openjdk7
      - openjdk6
    ```

    **Node**

    ```yml
    language: node_js
    node_js:
      - "0.10"
      - "0.8"
      - "0.6"
    ```

    如果 `.travis.yml` 文件存放路径有问题或者格式错误，此项目会被当成 ruby 默认处理。
4. 提交 `.travis.yml` 文件后，每次提交代码，[Travis CI](http://travis-ci.org/)都会自动执行脚本检测结果。


## .travis.yml 详情

此块内容以 [JavaScript (with Node.js)
](http://docs.travis-ci.com/user/languages/javascript-with-nodejs) 项目为主，其他语言项目请异步至[Travis CI Document](http://docs.travis-ci.com/)。

不管是 node 项目还是 javascript 项目，都可以通过 node 来完成代码检测和测试功能。

### 选择 node 版本。

```javascript
language: node_js
node_js:
  - "0.11"
  - "0.10"
  - "0.8"
  - "0.6"
```

可以允许指定多个版本，每个 node 版本都会在 vm 里面执行。

### 执行脚本

默认执行 `npm test`，如果 `.travis.yml` 里面没有指定。

你可以在 `package.json` 文件里面配置具体执行什么内容，如：

```json
"scripts": {
  "test": "node test.js"
}
```

另外还可以在 `.travis.yml` 中的 script 中指定其他 test 命令

```yml
language: node_js

node_js:
  - 0.10

before_script:
    - npm install -g grunt-cli

script:
    - grunt
```

注意 `before_script` 用来安装脚本依赖，比如这里面用 npm 安装了 grunt-cli。
PS: `npm install` 脚本不需要在此写入，自动会安装 npm 依赖。

另外通过 `before_install` 还可以指定一个 .sh 文件安装依赖。比如：

```yml
language: node_js
node_js:
  - "0.10"
before_install:
  - "curl -L http://git.io/3l-rRA | /bin/sh"
services:
  - mongodb
env:
  - LAIKA_OPTIONS="-t 5000"
```

另外也可以像方石的 [fis-project-analyzer](https://github.com/hefangshi/fis-project-analyzer) 项目中采用的方案，通过 makefile 来配置测试脚本。

`.travis.yml`

```yml
language: node_js
node_js:
  - "0.11"
  - "0.10"
  - "0.8"
script: make test-coveralls
```

makefile

```bash
TESTS = test/cases/*.js
REPORTER = spec
TIMEOUT = 10000
MOCHA_OPTS =

test:
    @NODE_ENV=test ./node_modules/.bin/mocha \
        --reporter $(REPORTER) \
        --timeout $(TIMEOUT) \
        $(MOCHA_OPTS) \
        $(TESTS)

test-cov:
    @rm -rf coverage.html
    @$(MAKE) -s test MOCHA_OPTS='--require blanket' REPORTER=html-cov > coverage.html
    @$(MAKE) -s test MOCHA_OPTS='--require blanket' REPORTER=travis-cov
    @ls -lh coverage.html

test-coveralls:
    @$(MAKE) test
    @echo TRAVIS_JOB_ID $(TRAVIS_JOB_ID)
    @-$(MAKE) test MOCHA_OPTS='--require blanket' REPORTER=mocha-lcov-reporter | ./node_modules/coveralls/bin/coveralls.js

test-all: test test-cov

.PHONY: test
```

脚本执行正确则 travis-ci 是通过状态，否则是失败状态。判断正确与否主要通过脚本结束时状态是 0 还是 1。1 表示有错误。

[更多资料](http://docs.travis-ci.com/user/languages/javascript-with-nodejs/)

## 单元测试

目前 [webuploader](https://github.com/fex-team/webuploader) 是基于 [QUnit](https://qunitjs.com/) 框架的, 这里给个示例。

流程：通过 [grunt-contrib-connect](https://github.com/gruntjs/grunt-contrib-connect) 开个简单的服务器，可以处理静态文件，然后通过
[grunt-contrib-qunit](https://github.com/gruntjs/grunt-contrib-qunit) 内嵌一个 node-webkit （无界面浏览器）打开刚刚开起的服务器，然后自动跑 QUnit 测试用例，有错误会被捕获。

Gruntfile.js 配置

```javascript
...

qunit: {
    all: {
        options: {
            urls: [
                'http://0.0.0.0:8000/test/index.html'
            ]
        }
    }
},

connect: {
    server: {
        options: {
            port: 8000,
            base: '.'
        }
    }
    /*,

    keepalive: {
        options: {
            port: 8000,
            base: '.',
            keepalive: true
        }
    }*/
},

...

grunt.registerTask('test', ['connect', 'qunit']);

// Default task(s).
grunt.registerTask('default', ['jsbint:all', 'test']);
```

另外，如果 [grunt-contrib-connect](https://github.com/gruntjs/grunt-contrib-connect) 不能胜任，比如 [gmu](https://github.com/fex-team/GMU) 测试框架是基于 php 的，需要服务器支持 php. 目前 [gmu](https://github.com/fex-team/GMU) 采用的方案是，在 before_script 用 apt  把 apache + php 安装好，再指定此服务器作为测试地址。

```yml
language: node_js

node_js:
  - 0.8

before_script:
    - sudo apt-get update
    - sudo apt-get install apache2
    - sudo apt-get install php5
    - sudo service apache2 restart
    - cd ../
    - sudo mv GMU /var/www/
    - cd /var/www/GMU
    - npm install -g grunt-cli
    - grunt update_submodules concat


script:
    - grunt test
```

## 规范检查

一般都是通过 [grunt-contrib-jshint](https://github.com/gruntjs/grunt-contrib-jshint) 工具，配合 `.jshint` 文件完成，然后把 grunt jshit 这个 task 加入到 travis-ci 脚本中。

[webuploader](https://github.com/fex-team/webuploader) 和 [gmu](https://github.com/fex-team/GMU) 由于采用的其他规范，所以目前采用的是 [grunt-jsbint](https://github.com/gmuteam/grunt-jsbint)。

后续等[fex规范](https://github.com/fex-team/styleguide)确定好了，再补充此文档。

