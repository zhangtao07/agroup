
# Google Plus 的技术调研

主要目的是了解在细节地方有什么可借鉴的

## 整体架构

* 后端
    - 基于 Guice 的 Java 代码
    - BitTable 和 Colossus
* 前端
    - 使用 Closure library、templates 和 compiler
    - 在页面中点击时有无刷新操作

## 前端页面 - 首页

URL：http://plus.google.com/

### 整体情况

导出的 har 文件高达 17M，由于缺少 httpVersion 字段，导致 har preview 不能展现

### http 相关

返回 headers（去掉了 cookie 等常见信息）为

```
协议相关
alternate-protocol:443:quic
strict-transport-security:max-age=10886400

无缓存
cache-control:no-cache, no-store, max-age=0, must-revalidate
date:Wed, 23 Apr 2014 05:42:18 GMT
expires:Fri, 01 Jan 1990 00:00:00 GMT
pragma:no-cache

安全相关
p3p:CP="This is not a P3P policy! See http://www.google.com/support/accounts/bin/answer.py?hl=en&answer=151657 for more info."
x-content-type-options:nosniff
x-frame-options:SAMEORIGIN
x-xss-protection:1; mode=block

其它
x-ua-compatible:IE=edge, chrome=1
```

可以看到 plus 已经用上 QUIC 协议了，另外有很多是安全相关的：

* 其中 p3p 是 cookie 相关，我们可以不管
* x-content-type-options 可以避免在 IE 下文本请求当成 HTML 来解析，导致安全问题
* x-frame-options 可以避免其它域名 iframe 的内嵌，具体看需求
* x-xss-protection 在浏览器下默认是开启的，这句话的作用是让即使用户关闭也开启

### HTML

初始返回的 HTML 还挺大，压缩前达到了 434k，比起贴吧首页的 150k 左右，plus 算很大了

页面底部有大量的给 JS 用的数据，有 193k，其中包括用户个人信息、好友信息、新闻等，因此这个页面其实主要渲染逻辑是 JavaScript 做的，数据格式类似下面的样子

```javascript
AF_initDataCallback({key: '161', isError:  false , data:["os.con",[[]
,"CAEQgOW56rbuvQIalAN4n...",[1,1,,,,20,,"social.google.com",[]
,,,,,,,[]
,,,2,,,0,,15,,[[1002,2]
,[111,100,102,103,136,105,106,107,109,115,114,116,112,113,152,153,141]
,0,0]
,[[5,1,8,4,7]
]
,,0,,,0,,,,0]
,,[]
,,,[[2,,[111,,0,,0]
]
```

这是一种深层数组结构，比起 JSON，它的体积会小很多（因为没有 key），但这样的数据是人类不可读的，这种格式在 Google 内部大量使用，几年前在 Google Calendar 我就见过，这些

### CSS

这个页面的 CSS 相当大，顶部有个外链的 CSS，如果是 noscript 版本高达 390k，URL 是

```
/_/scs/apps-static/_/ss/k=oz.home.bjrh3n48dtj9.L.W.O/m=s,rbdwr/am=AABMAgAYSAMBAABoIABEABBDDAAAKA/d=1/rs=AItRSTMXLNNUqqHgNkCp1P6JnE646ZI4Ew
```

基本可以肯定用了某种合成机制，另外还有一个内嵌的 CSS，有 36k

然后还会异步加载这个 534k 的 CSS

```
/_/scs/apps-static/_/ss/k=oz.home.bjrh3n48dtj9.L.W.O/am=AABMAgAYSAMBAABoIABEABBDDAAAKA/d=0/exm=s,rbdwr/ed=1/rs=AItRSTMXLNNUqqHgNkCp1P6JnE646ZI4Ew
```

看来 Google plus 并没有很好地解决 CSS 暴涨问题

### JS

1. 顶部有个 28k 的 JS，主要功能是：

* 性能监控，基于 performance.timing 或 chrome.csi()，还有打点功能
* 简单的模块定义
* 微小的浏览器兼容库，解决事件的不兼容问题，还有个小 ajax 请求库，提供加载 js 和 css 的功能

2. 然后一步加重一个体积居然为 1.4M（格式化后达到 2.5M） 的 JS，URL 为

```
<script id="base-js" src="/_/scs/apps-static/_/js/k=oz.home.en.u1MQU737Sjg.O/m=b,swc/am=AABMAgAYSAMBAABoIABEABBDDAAAKA/rt=j/d=1/z=zcms/rs=AItRSTNVDZcABtagf0Undk6VNRgf-cTj-A" async onload="ozIpStart();"></script>
```

基本上确认有基础库，还有圈人等公共操作的组件

3. 在导航栏下面又出现了一个 60k 的内嵌 JS，从其中的命名上看，做了好多编译优化，压得很厉害

```
(window['gbar'] = window['gbar'] || {})._DPG = [{
    'aw': ['sy1', 'sy17', 'sy2', 'sy21', 'sy9'],
```

这些其实是某个对象或类

这里面的代码比较难看懂，从功能上看，有些基础库的功能，比如浏览器判断、计算 computedStyle 等

4. 然后异步加载另一个 JS，这个 JS 不小，有 420k

```
OZ_requestJs(OZ_lateModuleIds, '\/_\/scs\/apps-static\/_\/js\/k\x3doz.home.en.u1MQU737Sjg.O\/m\x3dshbx,rbdwr,srbx\/am\x3dAABMAgAYSAMBAABoIABEABBDDAAAKA\/rt\x3dj\/d\x3d1\/exm\x3db,swc\/ed\x3d1\/z\x3dzcms\/rs\x3dAItRSTNVDZcABtagf0Undk6VNRgf-cTj-A', 'OZ_jsLoadSuccess', 'OZ_jsLoadError');
```

看上去都是业务逻辑相关的代码，基本上不可读

5. 异步加载了一个 api js，有 137k

```
["m;/_/scs/apps-static/_/js/k=oz.gapi.en.Zr8XO6POvOg.O/m=__features__/rt=j/d=1/z=zcms/rs=AItRSTNWDUOlBXtYKTYat_x6Da42EBHDFw","https://apis.google.com","","1","1","","APfa0bqQ-X63ZpZsrGwDUECiAy47vKafvtlgu3zv4zfoUjGvmsG3dLdmYfqwW2reyvT81axcphWxA7agOolmSJNagIZV0gW33g==",1,"unknown_version","en"]
```

貌似提供了 api 调用的通讯机制，比如通过 iframe 等

6. 然后还有好多个 JS，大部分是对数据的请求，这里就不介绍了

## Handouts

基于插件实现的视频会议，采用 C/S 架构而不是 P2P，所以看起来对后端要求比较高，据说后续打算使用 WebRTC 实现，但不清楚了。

这个技术效果还挺炫的，但目前看来机器成本还挺高，仅允许 10 人同时在线，话说还有个基于 WebRTC 实现的[开源版本](https://code.google.com/p/telepresence/)

## 图片编辑

图片是 Google Plus 的重点，所以它还专门对上传图片后的处理做了优化，提供[美图功能](http://www.theverge.com/2013/5/15/4333546/google-plus-new-features-photos-and-redesign)，还有一个基于 native client 写的[图片编辑工具](http://techcrunch.com/2013/09/15/googles-bet-on-native-client-brings-chrome-and-google-photos-closer-together/)

## 结论

Google plus 在代码压缩方面做得比我们好，比如数据格式等，但在前端架构方面是短板，页面体积实在太庞大了，感觉是想通过缓存和无刷新机制来解决性能问题，虽然首次加载很慢，但后续就好多了

