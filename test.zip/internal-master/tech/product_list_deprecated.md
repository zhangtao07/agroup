FEX Deprecated Products 
========

  一些已经不怎么被使用的产品。

### 在线文件管理组件 - ufinder

**简介：**一个基于浏览器的远程文件管理应用，可以提供媲美 native 的体验效果，致力于更方便地管理云端文件。ufinder使用了webuploader上传文件，充分发挥HTML5的优势，针对不同文件格式支持插件扩展，达到预览或编辑效果。  
**官网：**<http://fex.baidu.com/ufinder/>  
**负责人：**许金泉

### 移动端组件库 - GMU

**简介：** GMU是一个移动端组件库，具有代码体积小、简单、易用等特点，组件内部处理了很多移动端的bug，覆盖机型广，能大大减少开发交互型组件的工作量，非常适合移动端网站项目。  
**官网：**<http://gmu.baidu.com/>  
**负责人：**陈敏亮

### 跨端轻组件  - Cross

**简介：**缩小Web App和Native App的性能差距是轻组件的重要目标，通过轻组件能够让你的Web App拥有媲美Native App的交互、渲染能力，用户的交互体验将更加的顺畅。轻组件除了给web页面提供访问本地设备的能力外，还能够在web页面中嵌入Native功能，使用户能够享受到与本地APP同等的交互体验。  
**官网：**<http://fex.baidu.com/CROSS/>  
**负责人：**王集鹄

### 轻量级Webapp框架 - Chassis

**简介：** Chassis 是一套以提高Webapp开发效率为目的的开发框架。它提供了一套类Backbone的MVC代码架构，在此基础上延伸了视图层管理，优化了路由控制以及更加轻量级的实现。此外，基于Chassis的视图分层和开发规范，可以实现非常灵活的分工协作。  
**官网：**<https://github.com/baiduFe/Chassis>  
**负责人：**陈敏亮
