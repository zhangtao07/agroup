产品设计
========

fex 的工作，对产品规划与设计是有较高要求的，这个领域有不少和技术不同的思维方式需要我们去了解和适应。

## 度学堂-优秀视频

- 张贝妮： [唯破不快，敏捷迭代](http://learn.baidu.com/courseInfo.html?courseId=3000)
- 李明： [帮用户做出默认决策](http://learn.baidu.com/play.html?courseId=3068)
- 李东旻： [用户体验和用户习惯](http://learn.baidu.com/play.html?courseId=3199)
- 李东旻： [移动产品设计漫谈]( http://learn.baidu.com/play.html?courseId=3401)
- 肖轶： [消耗的用户成本VS提供的用户价值](http://learn.baidu.com/courseInfo.html?courseId=3301)
- 李小婉： [产品决策的成本和收益](http://learn.baidu.com/play.html?courseId=3541)

 
